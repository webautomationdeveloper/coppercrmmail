<?php 


require 'includes/PHPMailer.php';
require 'includes/SMTP.php';
require 'includes/Exception.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail= new PHPMailer();

$mail->isSMTP();
$mail->Host="smtp.gmail.com";
$mail->SMTPAuth="true";
$mail->SMTPSecure= "tls";
$mail->Port="587";
$mail->Username="webautomationdeveloper@gmail.com";
$mail->Password="Test@2021";
$mail->setFrom("webautomationdeveloper@gmail.com");
$mail->Body="this is for testing purpose";
$mail->addAddress("webautomationdeveloper@gmail.com");


echo 'test';
if( $mail->Send()){
    echo 'mail Sent';
}
else{
    echo 'mail not sent'; 
}
 $mail->smtpClose();



?>
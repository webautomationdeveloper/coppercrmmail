<?php 


require 'includes/PHPMailer.php';
require 'includes/SMTP.php';
require 'includes/Exception.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
$content = file_get_contents('mailTemplate.php');
$mail= new PHPMailer();

$mail->isSMTP();
$mail->Host="smtp.gmail.com";
$mail->SMTPAuth="true";
$mail->SMTPSecure= "tls";
$mail->Port="587";
$mail->Username="webautomationdeveloper@gmail.com";
$mail->Password="Test@2021";
$mail->setFrom("webautomationdeveloper@gmail.com");
$mail->isHTML(true); 
$mail->Body= ''.$content.'';
$mail->AddAttachment("attachment/1.png","image.png");
$mail->addAddress("webautomationdeveloper@gmail.com");



if( $mail->Send()){
    echo 'mail Sent';
}
else{
    echo 'mail not sent'; 
}
 $mail->smtpClose();

?>
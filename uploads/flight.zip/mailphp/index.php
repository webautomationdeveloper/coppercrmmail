<?php
$id= $_GET['ID'];
$url='https://api.copper.com/developer_api/v1/opportunities/'. $id;
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'X-PW-AccessToken: a39b249ed85ba1fb6ae770608184a5a9',
    'X-PW-Application: developer_api',
    'X-PW-UserEmail: webautomationdeveloper@gmail.com',
    'Content-Type: application/json',
    'Cookie: ; uuid=06c4e438-6cf5-41e2-9363-49d6b3489ee1; visited=true'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
// echo $response;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM Copper API Data</title>
</head>
<script>
    let data= <?php echo ($response); ?>;
    data.details="exist";
    data.tags="exist";
    data.interaction_count="exist";
    data.custom_fields="exists";
</script>
<style>
    /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 15% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 25%; /* Could be more or less, depending on screen size */
  border-radius: 50px;
}

/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
<button type="button" id="chkStatus">Check Status</button>

<div id="myModal" class="modal" >
  <div class="modal-content" id="modelContent">
    <span class="close">&times;</span>
    <p></p>
  </div>
<div id="mailtemplate" style="width: 100%;">
<textarea id="myTextarea"></textarea>
    
    <script src="//cdnjs.cloudflare.com/ajax/libs/tinymce/4.5.1/tinymce.min.js"></script>
    <script type="text/javascript">
        tinymce.init({
            selector: '#myTextarea',
            menubar: false,
            height: 500,
            statusbar: false,
            theme: 'modern',
            plugins: [
                'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      'searchreplace wordcount visualblocks visualchars code fullscreen',
      'insertdatetime media nonbreaking save table contextmenu directionality',
      'emoticons template paste textcolor colorpicker textpattern imagetools'
    ],
    toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    toolbar2: 'print preview media | forecolor backcolor emoticons',
    image_advtab: true
});
</script>
  </div>


</body>


<script>
    let clicked=false;
    $("#chkStatus").click(function(){
            if(data.status=="Open" && clicked==false){
                for (let [key, value] of Object.entries(data)) {
                    if(clicked==false) $("#modelContent").append(`<p>Set of missing keys</p>`);
                    if(value==""){
                        var found=true;
                        $("#modelContent").append(`<p>${key}</p>`);
                    }
                    clicked=true;
                }
                if(found==true) $(".modal").show();
            }

            if(data.status=="Close"){
              $("#modelContent").remove();
              $("#modelContent").append(`<h2>Status is closed cannot proceed</h2>`);
              $(".modal").show();
            }

            if(clicked==true){
                <?php 
                  
                  ?>;
            }
    })

    $(".close").click(function(){
        $(".modal").hide();
    });
</script>

</html>
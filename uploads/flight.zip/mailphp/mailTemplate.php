<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail template</title>
</head>

<body>
    <section>
        <p>Hello from the<a href="http://flightcharter.com.au/"> FlightCharter.com.au</a> team!</p>
        <p>We would like to request your availability and price for the following itinerary:</p>
        <p>

            <b>Reference:</b> <b>RFQ-101234</b>
        </p>
        <p>Your FlightCharter contact for this flight is:<strong> Cian Voets</strong></p>
        <p><b>Route Summary:</b> YNBR-YSWG//YSWG-YBCG//YBCG-YSBK</p>
        <p>Trip Type: <span>Return</span></p>

        <p>All Flight Operations quoted must be:</p>
        <ul>
            <li>Conducted under the IFR;</li>
            <li>Conducted in IFR equipped aircraft with a valid MR and MEL (if required / applicable) for the flight;
            </li>
            <li>Crewed by PIC with minimum qualifications of CPL MECIR;</li>
            <li>PIC must be current and recent on aircraft type and for any IAP that may be required;</li>
            <li>Must have a current IPC;</li>
            <li>Must have been checked to your line by your Chief Pilot.</li>
        </ul>
        <label for="">Leg 1:</label>
        <p>Narrabri Airport, Australia (NAA/YNBR) ETD 17-02-2021 07:00 (L) to Sydney Bankstown Airport (BWU/YSBK),
            Australia </p>
        <label for="">Leg 2:</label>
        <p>Narrabri Airport, Australia (NAA/YNBR) ETD 22-02-2021 13:00 (L) to Sydney Bankstown Airport (BWU/YSBK),
            Australia </p>
        <label for="">Leg 3:</label>
        <p>ETD (L) to</p>
        <label for="">Leg 4:</label>
        <p>ETD at (L) to</p>
        <label for="">Leg 5</label>
        <p>ETD (L) to .</p>
        <label for="">Leg 6:</label>
        <p>ETD (L) to</p>
        <p><strong>Number of PAX:</strong> 3</p>
        <p><strong>Trip Duration:</strong><span>Number of nights away:</span>3</p>
        <strong>Trip Notes :</strong>
        <p><b>Preferred Aircraft Types (if any; examples types follow)</b></p>
        <p>Twin piston engine; unpressurised, eg; C310, BE58, PA31,C402</p>
        <p>Twin piston engine; pressurised, eg; C414, C421</p>
        <p>Propjet single (ASEPTA); un-pressurised cabin, eg; C208</p>
        <p>Propjet single (ASEPTA); pressurised cabin, eg; PC12</p>
        <p>Propjet twin; pressurised cabin, eg; C441, BE20, B350</p>
        <p>Small business jet, eg; C510, C501</p>
        <p>Mid sized business jet, eg; C52A, E55P</p>
        <p>Large business jet, eg; C526</p>
        <p>Regional business jet, eg; CL60, FA50</p>
        <p>Global business jet, eg; GLF4, F900</p>
        <p>Regional airliner, eg; B190, JS32</p>
        <p>Regional airliner, eg; S340, DH8A, DH8C, F50, AT42</p>
        <p>Airliner; small, eg; F70, F100, E190</p>
        <p>Airliner; medium, eg; B737, A320</p>
        <p>Airliner; heavy, eg; B747, A330, A380</p>
        <p>Light helicopter, piston engine, eg; R44</p>
        <p>Turboshaft helicopter, eg; B206, AS350</p>
        <p>Twin turboshaft helicopter, eg; BK117, AW109, AS50</p>
    </section>
    <hr>
    <section>
        <strong>Your Response</strong>
        <p>Please reply via this email with:</p>
        <ul>
            <li>Availability</li>
            <li>Aircraft Type
                <ul>
                    <li type="circle">Please quote multiple types if you wish.</li>
                </ul>
            </li>
            <li>Callsign</li>
            <li><strong>Payload (pax & luggage) in kgs</strong></li>
            <li>Price EXCLUSIVE of GST</li>
            <li>Any relevant notes</li>
            
        </ul>

    </section>
    <hr>
    <section>
        <ul><label for="">NOTES:</label>
            <li>All times are local to the location unless otherwise stated.</li>
            <li>Prices must be your firm quotation for the stated itinerary</li>
            <li>Quotes to be provided only on available aircraft & crew</li>
            <li>Prices must include all charges including ground handling, crew expenses, head taxes, etc</li>
            <li>Price is to be quoted Exclusive of Australian GST</li>
            <li>Price must include all other value added taxes that may apply</li>
        </ul>
    </section>


    <p style="margin-top: 5em;margin-bottom: 5em;">--</p>

    <p style="color: grey;">Regards</p>
    <p>The Booking Team</p>
    <p><a href="http://flightcharter.com.au/">FlightCharter.com.au</a>Pty Ltd</p>
    <p>1800 687 354 | +612 8520 2087</p>
    <p><a href="http://flightcharter.com.au/">FlightCharter.com.au</a></p>
    <img src="https://ci4.googleusercontent.com/proxy/cEnVqJskKbdHvYcL3JFs-etP6tS_pOlEtDSsmqwMAvyt6dEb5N5GvG5sYlRyn8J6Fci_lQ2S1LndoGBiohNsvU2oK5WTPh5lCMV__E0L7uPlWhus0tsApFZI7ppXHaYB189ek92FjU6z=s0-d-e1-ft#https://flightcharter.com.au/wp-content/uploads/2017/06/FlightCharter-email-logo-3.png" alt="" width="50em" height="50em">
    <p><a href="https://flightcharter.com.au/covid-19-travel-restrictions-in-australia/">COVID-19 Travel Restrictions</a></p>

</body>

</html>
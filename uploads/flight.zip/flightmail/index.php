<?php
$id= $_GET['ID'];
$url='https://api.copper.com/developer_api/v1/opportunities/'. $id;
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => $url,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'X-PW-AccessToken: a39b249ed85ba1fb6ae770608184a5a9',
    'X-PW-Application: developer_api',
    'X-PW-UserEmail: webautomationdeveloper@gmail.com',
    'Content-Type: application/json',
    'Cookie: ; uuid=06c4e438-6cf5-41e2-9363-49d6b3489ee1; visited=true'
  ),
));

$response = curl_exec($curl);
curl_close($curl);
// echo $response;
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM MailSystem</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/tinymce/4.5.1/tinymce.min.js"></script>
    <script>
    let data= <?php echo ($response); ?>;
    data.details="exist";
    data.tags="exist";
    data.interaction_count="exist";
    data.custom_fields="exists";
</script>
</head>
<body>
    <!--check status button  -->
    <button type="button" id="chkStatus">Check Status</button>


    <!-- text box start from here -->
<div style="margin-top: 50px; display:none">
<textarea id="myTextarea">hello user you canter quotation here</textarea>
</div>

<!-- modal box start from here -->
<div id="myModal" class="modal" >
  <div class="modal-content" >
    <span class="close">&times;</span>
    <div id="modelContent"></div>
  </div>




<!-- status check script -->
<script>
 let clicked=false;
    $("#chkStatus").click(function(){
            if(data.status=="Open" && clicked==false){
                for (let [key, value] of Object.entries(data)) {
                    if(clicked==false) $("#modelContent").append(`<p>Set of missing keys</p>`);
                    if(value==""){
                        var found=true;
                        console.log(key);
                        $("#modelContent").append(`<p>${key}</p>`);
                    }
                    clicked=true;
                }
                if(found==true) $(".modal").show();
                else if(found==false)sendMail();
            }else if(data.error=='not_found'){
              $("#modelContent").append(`<h2>Some Error is there</h2>`);
              $(".modal").show();              
            }

            if(data.status=="Close"){
              $("#modelContent").append(`<h2>Status is closed cannot proceed</h2>`);
              $(".modal").show();
            }

            if(clicked==true){
                console.log(data);
            }
    })

    $(".close").click(function(){
        $(".modal").hide();
        $("#modelContent").remove();
    });

function sendMail(){
  $('#chkStatus').hide();
  $('#myTextarea').show();
}


</script>

<!-- tiny editor script -->
<script type="text/javascript">
tinymce.init({
    selector: '#myTextarea',
    height: 300,
    menubar: false,
    statusbar: false,
    theme: 'modern',
    plugins: [
      'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      'searchreplace wordcount visualblocks visualchars code fullscreen',
      'insertdatetime media nonbreaking save table contextmenu directionality',
      'emoticons template paste textcolor colorpicker textpattern imagetools'
    ],
    toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    toolbar2: 'print preview media | forecolor backcolor emoticons',
    image_advtab: true
});
</script>
</body>
</html>